#Main
Our homework 1 assigment was to create a "About Page" for Breast Cancer management.
The html file on this page shows our main code.
The Breast Cancer Managment is the group project that we work on it together.

#CSS
In the CSS folder we have our CSS code

#Media
In the media folder we put all the media we used such as picture, video and sound of the video.
