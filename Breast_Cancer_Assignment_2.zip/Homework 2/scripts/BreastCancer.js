function display() {
  var age = document.getElementById("age").value;
  var weight = document.getElementById(
    "weight").value;

  document.getElementById("ageDisplay").innerHTML =
    age;

  document.getElementById("weightDisplay").innerHTML =
    weight;
}