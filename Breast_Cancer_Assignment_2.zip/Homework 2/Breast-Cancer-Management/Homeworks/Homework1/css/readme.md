Here is our css code 
