# Breast-Cancer Management
Mobile Web App for Breast Cancer

Team Members: Laura and Alex,  Fall 2016

#Purpose of App
To create an interactive data sharing application between patient and doctor.
The patient inputs symptoms and test results, while doctors analyses the data and determines whether the patient is at risk of relapse, which leads to further evaluation.
The application was inspired by the many people who have or are suffering from breast cancer.

#Inspiration
Our family members were afected by Breast Cancer. We decided to create an App that would help cancer patients, to input data rather than constantly visit a doctor's office. This way, making it much easier for the Cancer patient to manage and cope with the disease.

##9/20/16
We will be focusing on Breast Cancer Managment. We want to help those that got diagnose with Breast cancer and allow them to find quick information and if needed to, get in contact with there doctor.
