This is the media we used for homework1
